/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 5 Baumgardt 0123456
 
  Program friedman (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This is program calculates the evolution of the universe according to 
         the Friedman equation using the RK4 method with fixed step size 
 
  Compile: gcc -Wall friedmann.c -o friedmann       
 
  Input: Stepsize dt (in Gyr), H_0 (in 1/Gyr) and cosmological constant \Lambda 
         (in 1/m^2) 
 
  Output: The age of the universe corresponding to this cosmology
***********************80*character*limit*good*for* a2ps***********************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define CLIGHT    2.99792458E8  // Speed of light in m/sec
#define GYR       3.1558E16     // 1 Gyr in sec
#define PARSEC    3.08576E13    // 1 parsec in km 

double lconst;    // Value for 0.5*Lambda*c^2

int main() {
 double thubble,lambda;
 double dt,dtout,dadt,dbdt;
 double a,b,t=0.0,tout=0.0;
 void runge_kutta();
 FILE *dat;

 printf("\nThis program solves the Friedman equation to determine the age of the universe");

 printf("\n\nEnter the Hubble constant in km/sec/Mpc: ");
 scanf("%lf",&thubble);
 thubble /= (PARSEC*1E6);

 printf("\nEnter the cosmological constant in 1/m^2: ");
 scanf("%lf",&lambda);

 printf("\nEnter the time step in Gyr (enter negative dt to integrate backwards): ");
 scanf("%lf",&dt);

 printf("\nEnter the output time step in Gyr (enter negative dtout to integrate backwards): ");
 scanf("%lf",&dtout);

 thubble = thubble*GYR;                       // Hubble constant in 1/Gyr 
 lconst  = 0.5*lambda*CLIGHT*CLIGHT*GYR*GYR;  // 0.5*lambda*c^2 in 1/Gyr^2

// Setting the starting values for a and b
 a = 1.0;
 b = thubble;    

 dat = fopen("as06output.dat","w");

 do {
   if (t<=tout) {
     fprintf(dat,"%lf %lf %lf\n",t,a,b);
     tout += dtout;
   }

   runge_kutta(a,b,dt,&dadt,&dbdt);   // Make one Runge-Kutta step and return values for da/dt and db/dt

   a += dadt*dt;
   b += dbdt*dt;

   t += dt;
 } while (a>0.01);
 fclose(dat);

 printf("\nAge of the universe: %lf\n\n",-t); 
 exit(0);
}

void runge_kutta(double a,double b, double dt, double *dadt, double *dbdt) {
 double adot1,adot2,adot3,adot4,bdot1,bdot2,bdot3,bdot4;

 adot1 = b;
 bdot1 = lconst*a-0.5*pow(b,2.0)/a;

 adot2 = b+0.5*dt*bdot1;
 bdot2 = lconst*(a+0.5*dt*adot1)-0.5*pow(b+0.5*dt*bdot1,2.0)/(a+0.5*dt*adot1);

 adot3 = b+0.5*dt*bdot2; 
 bdot3 = lconst*(a+0.5*dt*adot2)-0.5*pow(b+0.5*dt*bdot2,2.0)/(a+0.5*dt*adot2);

 adot4 = b+dt*bdot3; 
 bdot4 = lconst*(a+dt*adot3)-0.5*pow(b+dt*bdot3,2.0)/(a+dt*adot3);

 *dadt = 1.0/6.0*(adot1+2.0*adot2+2.0*adot3+adot4);
 *dbdt = 1.0/6.0*(bdot1+2.0*bdot2+2.0*bdot3+bdot4); 
}
